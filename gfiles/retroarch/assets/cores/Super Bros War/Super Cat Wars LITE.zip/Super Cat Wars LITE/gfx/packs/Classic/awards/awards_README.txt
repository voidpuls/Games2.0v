--------------------------------------------
GFX Pack - Awards
--------------------------------------------
The following denote the purposes of the images used here:

- award - used for the Roulette Wheel, spins to choose from a circle of items
- killsinrow - used for the Ring Kills-in-Row eyecandy.
- killsinrownumbers - used for combo fireworks
- souls - used for the Soul Kills-in-Row eyecandy, these fly out of the player when they have chained combos.
- soulspawn - This graphic is the spawnpoint of the flying soul graphics in the Soul eyecandy. It eventually disappears after all the souls have flown out.