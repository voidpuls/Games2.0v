--------------------------------------------
GFX Pack - Hazards
--------------------------------------------
The following denote the purposes of the images used here. Note that all hazards contain regular, preview (1x), and thumbnail (0.5x) versions, used for map previews and thumbnails.

NOTE: The file "Copy of rotodisc" is unused and is a leftover from the game's development. You can delete it if you see it in the game's files.

- bulletbill - Denotes the Bullet Bill hazard, which uses two directions.
- fireball - Denotes the Firebar hazard + the fireball projectiles used by Fire Piranha Plants/Monkeys/Vulcan Turnips. There are two rows that indicate direction.
- flame - Denotes the Flamethrower hazard. The sheet shows four frames for left, right, up, and down directions.
- piranhaplant - A collective sprite sheet containing sprites for the Piranha Plants and Fire Piranhas (Monkeys, Vulcan Turnips, Mr. Prickles and Bamboo Blossom in SCW).
- rotodisc - Rotodiscs/Electorbs. Said hazard contains 21 unique frames for its animation.