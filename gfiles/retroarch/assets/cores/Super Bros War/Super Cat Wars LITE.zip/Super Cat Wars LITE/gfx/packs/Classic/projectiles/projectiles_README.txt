--------------------------------------------
GFX Pack - Projectiles
--------------------------------------------
The following denote the purposes of the images used here. The four colors correspond to each of the players (red for P1, green for P2, yellow for P3, blue for P4)

- bomb - Bomb projectiles from the bomb powerup. The black ones are only used by the Bomb Bro.
- boomerang - Boomerangs, they come in two directions and four frames per direction.
- bulletbill - Bullet Bills/birds. They come in two directions per player and four frames per direction. Top row faces left, bottom row faces right.
- fireball - Fireballs, in two directions and four frames per direction.
- hammer - Throwable hammers. There are six unique animation frames for each ahmmer.
- shell - Animations for the throwable shells and their upside-down variants. They are ordered like this: (Green-Red-Spiny-Buzzy), then (UpsideDown:Green-Red-Spiny-Buzzy).
- statue - Tanooki statues. The statue collar or team symbol corresponds to the player itself.
- throwblock - Animations for the throwable blocks when held and thrown. Top one is blue, middle one is gray, and bottom is red.
- wandblast - Wand blasts, used by the Ice Wand. The regular one goes unused (possibly an April Fools Edition remnant or planned feature or Beta 3), but the team color ones are actually used in-game.