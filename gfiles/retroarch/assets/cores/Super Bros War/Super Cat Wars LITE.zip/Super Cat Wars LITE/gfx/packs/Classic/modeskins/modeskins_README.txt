--------------------------------------------
GFX Pack - Mode Skins
--------------------------------------------
The following denote the purposes of the images used here. Note that these also act as regular skins, so you can use them however you like outside of their respective gamemodes by dropping these skins into the gfx/skins folder. (Just prepare to be confused if you're doing that.)

- bobomb - Skin for the Bob-omb/Kobolt Jr powerup
- chicken - Skin for the Chicken in Chicken mode
- shyguy - Skin for the ShyGuy/Robot in Shy Guy Tag/Robo Tag mode