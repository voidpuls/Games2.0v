--------------------------------------------
GFX Pack - World
--------------------------------------------
The following denote the purposes of the images used here. 

- world_background - Used to denote the water and ground tiles on the world map.
- world_bonushouse - Used to denote the graphics for the Toad House/Bonus Shop.
- world_bonusplace - The top small blocks are used to indicate item rewards for 1st, 2nd, 3rd, and 4th places, while the FINAL STAGE banner is used for the end stage in the world map.
- world_foreground - Used to denote all world decoration. The last two columns in the decoration select screen in the world editor are also animated tiles.
- world_foreground_special - Numbered levels, which are also used for the vehicle barriers & enterable stages. There are also sprites for the starting points, completed stages, locked doors, and drawbridges.
- world_item_popup - The player's inventory, which contains four colors for each player. The item boxes on the bottom denote the player's selected powerup.
- world_paths - Sprites for the world paths.
- world_powerups - Sprites for the powerups exclusive to World Mode.
- world_powerupssmall - Same as above, but in 1x pixels, used for powerup rewards on stage previews.
- world_vehicles - Sprites for the vehicle ambushes.

The folder also contains two subfolders: "preview" (1x pixel images) and "thumbnail" (0.5x pixel images) used for world previews and world thumbnails (for screenshots, World Mode overview, etc.) The following are included:
- world_background
- world_foreground
- world_foreground_special
- world_paths
- world_vehicles