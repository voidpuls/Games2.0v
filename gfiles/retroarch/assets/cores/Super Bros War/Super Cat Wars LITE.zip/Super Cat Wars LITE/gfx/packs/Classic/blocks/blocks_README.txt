--------------------------------------------
GFX Pack - Blocks
--------------------------------------------
The following denote the purposes of the images used here:

- bounceblock - Graphics for the Bounce Block, a block which kills players standing on them if it's hit.
- breakableblock - Graphics for the Brick/Yellow Stone Block which is destroyed upon hitting it
- donutblock - Graphics for the Donut Block/Falling Log. The falling variant of this block is handled by a similar-looking donut block in the Classic tileset, which should also be changed as well, should the player wish to change this block's appearance.
- flipblock - Graphics for the Rotating Block. The first frame is used when the block is not rotating, and it animates when the player hits it, and becomes intangible for a short while.
- noteblock - Graphics for the Note Block/Mushroom Block, the top one is the weakest, the middle one is a normal version, and the bottom one is the strongest version with a strong high-jump.
- powerupblock - Graphics for the ? Block/Star Block, which produces items upon being hit. Top frames indicates an active state, while the bottom one indicates an inactive state. Both states can be animated.
- switchblock - Collective sprite sheet for the On-Off switches & Switch Blocks. Each column follows these graphics from top to bottom: Switch (ON), Switch (OFF), Block (SOLID), Block (DOTTED-LINE). Columns in order are red, green, yellow, and blue.
- throwblock - Graphics for the throwable blocks/bricks. Blue one is the weakest, gray one is stronger and can chain combo kills until hitting a wall, and red ones act like an invincible Shell.
- viewblock - Graphics for the Roulette Block, which have a single frame for its active and inactive state. The active state should have transparent space to ensure the items display properly, as it is the point of the Roulette Block itself.
- weaponbreakableblock - Graphics for the Weapon Blocks. They follow this order: Fire-Cape-Shell-Bomb-Boomerang-Hammer-Shoe-Balloon-Star-Leaf. These blocks don't have to look the same, by the way, so go ham!